import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

void main() {
  runApp( const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Pomodoro(),

  ));
}
class Pomodoro extends StatefulWidget {
  const Pomodoro({Key? key}) : super(key: key);

  @override
  State<Pomodoro> createState() => _PomodoroState();
}

class _PomodoroState extends State<Pomodoro> {
  double percent = 0;
  static int TimeMinuto = 25;
  int TimeSegundo = TimeMinuto * 60;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xff8d8e8f), Color(0xff67a5b2), Color(0xff4dcee5)],
                begin:FractionalOffset(0.5,1)
            )
          ),
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const <Widget>[
              Padding(
                  padding: EdgeInsets.only(top: 20.0),
                child: Text(
                  'Relógio Pomodoro para estudos',
                  style: TextStyle(
                    color: Color(0xff43b9b9),
                    fontSize: 38.0
                  ),

                ),

              ),
              Expanded(
                  child: const CircularPercentIndicator(
                    percent: percent,
                    animation: true,
                    animateFromLastPercent: true,
                    radius: 230.0,

              ),
              )
            ],
          ),
        ),

      ),
    );
  }
}



package com.example.testefinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
